# Notes-Maker
 
Hi their this is themam presenting you Notes Maker a simple notes taking software made with python.

# Pre-required 
1. Python (recommanded : python v3)
2. Desktop OS : Windows or Mac
{ This you can also run on Mobile Termux }

# Process for Windows or Mac
1. Download the repository or clone it with the command given bellow 
    { git clone https://github.com/Muzammil538/Notes-Maker.git }

2. Open the folder in your code editor or Terminal and run the file by the given command 
    { python3 notes-maker.py}

    Rest follow the instruction given in the program.
    Have a great day 🙂

# Process for Termux 

Follow the bellow commands to run the program.

apt-get update <br>
apt-get upgrade<br>
apt-get install python3<br>
apt-get install git<br>
git clone https://github.com/Muzammil538/Notes-Maker.git <br>
cd Notes-Maker<br>
chmod +x *<br>
python3 notes-maker.py<br>